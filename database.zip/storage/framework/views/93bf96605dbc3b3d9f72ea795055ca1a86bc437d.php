
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
            echo Form::open(array('url' => '/upload','files'=>'true'));
            echo 'Select the file to upload.';
            echo Form::file('image', ['required']);
            echo Form::submit('Upload Image');
            echo Form::close();
        ?>
    </div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\imll\imgd\resources\views/images/upload.blade.php ENDPATH**/ ?>