<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">
    <style>
        .hidden {
            display: none;
        }
    </style>
    <div class="c-sidebar-brand d-md-down-none">
        Image metadata
    </div>

    <ul class="c-sidebar-nav">
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(url('/')); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt"></i>
                Images
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(url('/upload')); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt"></i>
                Upload File
            </a>
        </li>
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(url('/download')); ?>" class="c-sidebar-nav-link">
                <i class="fa-fw fas fa-cogs c-sidebar-nav-icon"></i>
                From URL
            </a>
        </li>
    </ul>

</div><?php /**PATH C:\wamp64\www\imll\imgd\resources\views/partials/menu.blade.php ENDPATH**/ ?>