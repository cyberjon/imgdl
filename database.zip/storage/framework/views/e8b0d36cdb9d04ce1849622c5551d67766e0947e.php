
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
            echo Form::open(array('url' => '/download','files'=>'true'));
            echo 'Enter image URL to upload.';
            echo Form::text('url', '', ['required']);
            echo Form::submit('Save Image');
            echo Form::close();
        ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\imll\imgd\resources\views/images/download.blade.php ENDPATH**/ ?>